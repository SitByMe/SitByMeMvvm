package com.sitbyme.mvvm;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import java.util.Map;

import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;

/**
 * @author SitByMe
 * date  : 2021/3/4
 * desc  : activity 基类
 */
public abstract class AbsVmActivity<VM extends AbsViewModel> extends AppCompatActivity implements IUi {
    public VM viewModel;
    /**
     * 管理RxJava，主要针对RxJava异步操作造成的内存泄漏
     */
    private CompositeDisposable compositeDisposable;

    public final void addDisposable(@NonNull Disposable d) {
        if (compositeDisposable == null) {
            compositeDisposable = new CompositeDisposable();
        }
        compositeDisposable.add(d);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        viewModel = new ViewModelProvider(this,
                new ViewModelProvider.AndroidViewModelFactory(getApplication())).get(getViewModelClass());
        //私有的ViewModel与View的契约事件回调逻辑
        registerUiChangeLiveData();
        super.onCreate(savedInstanceState);
    }

    /**
     * 指定 ViewModel 的类型
     *
     * @return the class type of viewModel
     */
    public abstract Class<VM> getViewModelClass();

    /**
     * 私有的ViewModel与View的契约事件回调逻辑
     */
    private void registerUiChangeLiveData() {
        //加载对话框显示
        viewModel.getUc().getShowDialogEvent().observe(this, new Observer<LoadingDataBean>() {
            @Override
            public void onChanged(@Nullable LoadingDataBean loadingDataBean) {
                showLoading(loadingDataBean);
            }
        });
        //加载对话框消失
        viewModel.getUc().getDismissDialogEvent().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                dismissLoading();
            }
        });
        //弹出Toast
        viewModel.getUc().getShowToastEvent().observe(this, new Observer<CharSequence>() {
            @Override
            public void onChanged(@Nullable CharSequence charSequence) {
                showToast(charSequence);
            }
        });
        //跳入新页面
        viewModel.getUc().getStartActivityEvent().observe(this,
                new Observer<Map<String, Object>>() {
                    @Override
                    public void onChanged(@Nullable Map<String, Object> params) {
                        if (params == null) {
                            showToast("启动页面参数为空！");
                        } else {
                            Class<?> clz = (Class<?>) params.get(AbsViewModel.ParameterField.CLASS);
                            Bundle bundle = (Bundle) params.get(AbsViewModel.ParameterField.BUNDLE);
                            Intent intent = new Intent(AbsVmActivity.this.getApplicationContext(), clz);
                            if (bundle != null) {
                                intent.putExtras(bundle);
                            }
                            startActivity(intent);
                        }
                    }
                });
        //关闭界面
        viewModel.getUc().getFinishEvent().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                finishAct();
            }
        });
        //关闭上一层
        viewModel.getUc().getOnBackPressedEvent().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                onBackPressed();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // ViewModel销毁时会执行，同事取消所有异步操作
        if (compositeDisposable != null) {
            compositeDisposable.clear();
        }
    }
}
